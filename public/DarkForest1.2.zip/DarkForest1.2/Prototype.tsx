<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="prototype" tilewidth="16" tileheight="16" tilecount="110" columns="11">
 <image source="Sprite-0001.png" width="178" height="162"/>
</tileset>
